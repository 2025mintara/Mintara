
  # Mintara Base Design Prototype

  This is a code bundle for Mintara Base Design Prototype. The original project is available at https://www.figma.com/design/Th0x3GmYxL1zZqy4tDBGNu/Mintara-Base-Design-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  