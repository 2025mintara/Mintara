import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './components/pages/Home';
import { TokenBuilder } from './components/pages/TokenBuilder';
import { AINFTBuilder } from './components/pages/AINFTBuilder';
import { Dashboard } from './components/pages/Dashboard';
import { Whitepaper } from './components/pages/Whitepaper';
import { Launchpad } from './components/pages/Launchpad';
import { Toaster } from './components/ui/sonner';
import { WalletProvider } from './components/WalletContext';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    // FORCE DESKTOP MODE - Override all viewport settings
    const setDesktopViewport = () => {
      // Remove all existing viewport meta tags
      const existingMetas = document.querySelectorAll('meta[name="viewport"]');
      existingMetas.forEach(meta => meta.remove());
      
      // Add new desktop viewport
      const viewportMeta = document.createElement('meta');
      viewportMeta.setAttribute('name', 'viewport');
      viewportMeta.setAttribute('content', 'width=1440, initial-scale=1.0, minimum-scale=1.0, maximum-scale=5.0, user-scalable=yes');
      document.head.appendChild(viewportMeta);
      
      // Force desktop dimensions
      document.documentElement.style.cssText = 'min-width: 1440px !important; width: 100% !important; overflow-x: auto !important;';
      document.body.style.cssText += 'min-width: 1440px !important; width: 100% !important; overflow-x: auto !important;';
      
      // Force root container
      const root = document.getElementById('root');
      if (root) {
        root.style.cssText = 'min-width: 1440px !important; width: 100% !important;';
      }
    };
    
    setDesktopViewport();
    
    // Re-apply after a small delay to ensure it sticks
    setTimeout(setDesktopViewport, 100);
    setTimeout(setDesktopViewport, 500);
    
    // Add page transition animation
    document.body.style.opacity = '0';
    setTimeout(() => {
      document.body.style.transition = 'opacity 0.3s ease-in-out';
      document.body.style.opacity = '1';
    }, 10);
  }, [currentPage]);

  return (
    <WalletProvider>
      <div className="min-h-screen w-full" style={{ minWidth: '1440px', width: '100%' }}>
        <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
        
        <main className="w-full" style={{ minWidth: '1440px', width: '100%' }}>
          {currentPage === 'home' && <Home onNavigate={handleNavigate} />}
          {currentPage === 'token-builder' && <TokenBuilder onNavigate={handleNavigate} />}
          {currentPage === 'ai-nft-builder' && <AINFTBuilder onNavigate={handleNavigate} />}
          {currentPage === 'dashboard' && <Dashboard onNavigate={handleNavigate} />}
          {currentPage === 'whitepaper' && <Whitepaper />}
          {currentPage === 'launchpad' && <Launchpad onNavigate={handleNavigate} />}
        </main>

        <Footer onNavigate={handleNavigate} />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#03261B',
              color: '#E8FFF5',
              border: '1px solid #2C5E51',
            },
          }}
        />
      </div>
    </WalletProvider>
  );
}

export default App;
